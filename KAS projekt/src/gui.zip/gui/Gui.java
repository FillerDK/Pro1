package gui;

import controller.Controller;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import model.Deltager;

public class Gui extends Application {
    Stage window;
    Scene loginScene, opretScene, minScene;

    @Override
    public void start(Stage mainStage) {
        window = mainStage;
        window.setTitle("KAS");
        BorderPane pane = new BorderPane();

        loginScene = new Scene(pane);

        this.initContent(pane);

        window.setScene(loginScene);
        window.show();
    }

    // -------------------------------------------------------------------------

    private void initContent(BorderPane pane) {
        TabPane tabPane = new TabPane();
        this.initTabPane(tabPane);

        GridPane gridPane = new GridPane();
        this.initLogin(gridPane);
        pane.setCenter(gridPane);
    }

    private void initLogin(GridPane pane) {
        gPaneDefault(pane);

        Label lblLogin = new Label("Log in");
        pane.add(lblLogin, 0, 0);
        GridPane.setHalignment(lblLogin, HPos.CENTER);

        TextField txfEmail = new TextField();
        txfEmail.setPromptText("Email");
        pane.add(txfEmail, 0, 1);

        PasswordField pswAdgangskode = new PasswordField();
        pswAdgangskode.setPromptText("Adganskode");
        pane.add(pswAdgangskode, 0, 2);

        Button btnOpretLogin = new Button("Opret Bruger");
        btnOpretLogin.setPrefWidth(100);


        Button btnLogin = new Button("Login");
        btnLogin.setPrefWidth(100);

        HBox hbxKnapper = new HBox();
        hbxKnapper.setSpacing(10);
        hbxKnapper.getChildren().addAll(btnOpretLogin, btnLogin);
        pane.add(hbxKnapper, 0, 3);

        // Alle init henvisninger
        GridPane opretPane = new GridPane();
        opretScene = new Scene(opretPane);
        this.initOpret(opretPane);

        BorderPane minPane = new BorderPane();
        minScene = new Scene(minPane);

        // Hent deltager
        //Deltager deltager = Controller.opretDeltager(navn, tlf, email, adresse);
        this.initMin(minPane);

        // Fjerner fokus fra valgte node
        loginScene.setOnMouseClicked(event -> {
            if (!txfEmail.equals(event.getSource())) {
                txfEmail.getParent().requestFocus();
            }
        });

        // Alle actions
        btnOpretLogin.setOnAction(event -> window.setScene(opretScene));
        btnLogin.setOnAction(event -> window.setScene(minScene));
    }

    private void initOpret(GridPane pane) {
        gPaneDefault(pane);

        Label lblOpret = new Label("Opret Bruger");
        pane.add(lblOpret, 0, 0);
        GridPane.setHalignment(lblOpret, HPos.CENTER);

        TextField txfNavn = new TextField();
        txfNavn.setPromptText("Navn");
        pane.add(txfNavn, 0, 1);

        TextField txfTlf = new TextField();
        txfTlf.setPromptText("Tlf. nr.");
        pane.add(txfTlf, 0, 2);

        TextField txfEmail = new TextField();
        txfEmail.setPromptText("Email");
        pane.add(txfEmail, 0, 3);

        PasswordField pswAdgangskode = new PasswordField();
        pswAdgangskode.setPromptText("Adgangskode");
        pane.add(pswAdgangskode, 0, 4);

        TextField txfAdresse = new TextField();
        txfAdresse.setPromptText("Adresse");
        pane.add(txfAdresse, 0, 5);

        Button btnAnnuller = new Button("Annuller");
        btnAnnuller.setPrefWidth(100);

        Button btnOpret = new Button("Opret");
        btnOpret.setPrefWidth(100);

        HBox hbxKnapper = new HBox();
        hbxKnapper.setSpacing(10);
        hbxKnapper.getChildren().addAll(btnAnnuller, btnOpret);
        pane.add(hbxKnapper, 0, 6);

        // Evt. lav hjælpemetode til at skabe deltager
        // OBS! Mangler stadig at tilføje visse oplysninger
        String navn = txfNavn.getText().trim();
        String tlf = txfTlf.getText().trim();
        String email = txfEmail.getText().trim();
        String adresse = txfAdresse.getText().trim();
        Deltager deltager = new Deltager(navn, tlf, email, adresse);

        btnAnnuller.setOnAction(event -> window.setScene(loginScene));

        btnOpret.setOnAction(event -> window.setScene(minScene));

        opretScene.setOnMouseClicked(event -> {
            if (!txfEmail.equals(event.getSource())) {
                txfEmail.getParent().requestFocus();
            }
        });
    }

    private void initMin(BorderPane pane) {
        // Mine tilmeldinger --- venstre pane
        GridPane tPane = new GridPane();
        gPaneDefault(tPane);
        pane.setLeft(tPane);

        Label tilmeldinger = new Label("Mine tilmeldinger");
        tPane.add(tilmeldinger, 0, 0);
        GridPane.setHalignment(tilmeldinger, HPos.CENTER);

        ListView lvwTilmeldinger = new ListView();

        // Hent deltager
        //String email = txfEmail.getText().trim();
        //String adgangskode = txfAdgandskode.getText().trim();
        //Deltager deltager = Controller.hentDeltager(email, adgangskode);
        // Hent deltagers tilmeldinger
        //lvwTilmeldinger.getItems().setAll(Controller.hentTilmeldinger(deltager));
        tPane.add(lvwTilmeldinger, 0, 1);

        Button btnOpretTilmelding = new Button("Opret tilmelding");
        btnOpretTilmelding.setPrefWidth(150);

        Button btnInfo = new Button("Vis info");
        btnInfo.setPrefWidth(150);

        HBox hbxKnapper = new HBox();
        hbxKnapper.setSpacing(10);
        hbxKnapper.getChildren().addAll(btnOpretTilmelding, btnInfo);
        tPane.add(hbxKnapper, 0, 2);

        // Mine oplysninger --- højre pane
        GridPane oPane = new GridPane();
        gPaneDefault(oPane);
        pane.setRight(oPane);

        Label lblOplysninger = new Label("Mine oplysninger");
        oPane.add(lblOplysninger, 0, 0);

        // OBS !!! Midlertidigt !!!
        Deltager deltager = new Deltager("Jens", "00000000", "jens@gmail.com", "Jensens Gade 11");

        Label lblNavn = new Label("Navn:");
        oPane.add(lblNavn, 0, 1);

        TextField txfNavn = new TextField();
        txfNavn.setText(deltager.getNavn());
        oPane.add(txfNavn, 0, 2);

        Label lblTlf = new Label("Tlf:");
        oPane.add(lblTlf, 0, 3);

        TextField txfTlf = new TextField();
        oPane.add(txfTlf, 0, 4);

        Label lblEmail = new Label("Email:");
        oPane.add(lblEmail, 0, 5);

        TextField txfEmail = new TextField();
        oPane.add(txfEmail, 0, 6);

        //----------------
        PasswordField pswAdgangskode = new PasswordField();
        oPane.add(pswAdgangskode, 0, 4);

        TextField txfAdresse = new TextField();
        oPane.add(txfAdresse, 0, 5);

        Button btnOpdater = new Button("Opdater");
        btnOpdater.setPrefWidth(150);
        oPane.add(btnOpdater, 0, 6);
    }

    private void initTabPane(TabPane tabPane) {
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Tab tabKonferencer = new Tab("Konferencer");
        tabPane.getTabs().add(tabKonferencer);

        KonferencePane konferencePane = new KonferencePane();
        tabKonferencer.setContent(konferencePane);
        tabKonferencer.setOnSelectionChanged(event -> konferencePane.updateControls());
    }

    private void gPaneDefault(GridPane pane) {
        pane.setPadding(new Insets(20));
        pane.setHgap(10);
        pane.setVgap(10);
    }
}
