package gui;

import controller.Controller;
import javafx.geometry.Insets;
import javafx.scene.control.ListView;
import javafx.scene.layout.GridPane;
import model.Konference;

public class KonferencePane extends GridPane {
    ListView<Konference> lvwKonference = new ListView<>();

    public KonferencePane() {
        this.setPadding(new Insets(20));
        this.setHgap(20);
        this.setVgap(10);
        this.setGridLinesVisible(false);

        lvwKonference.getItems().setAll(Controller.hentKonferencer());
        this.add(lvwKonference, 0, 0);
    }

    public void updateControls() {
        Konference konference = lvwKonference.getSelectionModel().getSelectedItem();
        /*if (company != null) {
            txfName.setText(company.getName());
            txfHours.setText("" + company.getHours());
            StringBuilder sb = new StringBuilder();
            for (Employee emp : company.getEmployees()) {
                sb.append(emp).append("\n");
            }
            txaEmployees.setText(sb.toString());
        } else {
            txfName.clear();
            txfHours.clear();
            txaEmployees.clear();
        }*/
    }
}
